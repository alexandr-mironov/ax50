1. System Analyzer
-------------------------------------
System analyzer tool to analyze the logs collected from the PAD ( Probe and Debug ) .

2. PAD 
-------------------------------------
The probe and debug (PAD) application is an information tool run�s in the CPE. This application will run sub-system related commands and tool for storage, performance etc., and collect configuration and log information from the CPE. 

3. Valgrind
-------------------------------------
Valgrind is an instrumentation framework for building dynamic analysis tools. There are Valgrind tools that can automatically detect many memory management and threading bugs, and profile your programs in detail.It comes with a set of tools each of which performs some kind of debugging, profiling, or similar task that helps you improve your programs.

4. strace 
-------------------------------------
strace is a tool for tracing system calls and signals It intercepts and records the system calls made by a running process. strace can print a record of each system call, its arguments, and its return value.

5. getphymem
-------------------------------------
A small utility to display the physical RAM usage of a user space application. This utility is based on /proc/<pid>/smaps interface which gives physical usage of a process.

6. readchip 
-------------------------------------
Utility gives information about chip like part number, version etc., 

7. gdb
-------------------------------------
GDB, the GNU Project debugger, allows you to see what is going on `inside' another program while it executes.

8. tcpdump
-------------------------------------
tcpdump is a common packet analyzer that runs under the command line. It allows the user to display TCP/IP and other packets being transmitted or received over a network to which the computer is attached.

9. ethtool
-------------------------------------
ethtool is a utility for Linux kernel-based operating system for displaying and modifying some parameters of network interface controllers (NICs) and their device drivers.

10. dwatch 
-------------------------------------
Dwatch (Daemon Watch) is a program that watches over other programs and performs actions based on conditions specified in a configuration file.

11. ppacmd
-------------------------------------
ppacmd is a utility used to configure the switch.

12. dsl_cpe_pipe
-------------------------------------
utility to access various dsl related information.


